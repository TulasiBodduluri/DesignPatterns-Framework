package demo4;

public class Demo4_1 {
	private static void privateFunc() {
        System.out.println("This is a private method in superclass.");
    }
    
    public static void publicFunc() {
        System.out.println("This is a public method in superclass.");
    }
}
