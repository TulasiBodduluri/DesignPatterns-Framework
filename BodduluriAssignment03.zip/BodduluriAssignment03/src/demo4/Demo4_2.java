package demo4;

public class Demo4_2 extends Demo4_1{
	// This is a new method and not an override of the privateMethod in superclass
    private static void privateFunc() {
        System.out.println("This is a private method in subclass.");
    }
    
    // This is a new method and not an override of the publicMethod in superclass
    public static void publicFunc() {
        System.out.println("This is a public method in subclass.");
    }
}
