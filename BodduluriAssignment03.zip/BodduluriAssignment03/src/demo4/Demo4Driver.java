package demo4;

public class Demo4Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo4_1.publicFunc(); // Output: This is a public method in superclass.
        Demo4_2.publicFunc(); // Output: This is a public method in subclass.

       // Demo4_1.privateFunc(); // Error: The method privateFunc() from the type Superclass is not visible
        //Demo4_2.privateFunc(); // Error: The method privateFunc() from the type Subclass is not visible
	}

}
