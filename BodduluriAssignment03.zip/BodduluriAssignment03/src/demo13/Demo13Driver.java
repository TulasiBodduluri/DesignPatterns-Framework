package demo13;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;

public class Demo13Driver {
	public static void main (String[] args) {
        ArrayList<String> arr = new ArrayList<String>();
        arr.add("Nikki");
        arr.add("Vidya");
        arr.add("Sreej");
        arr.add("Usha");
        System.out.println("Elements in arrayList:");
        Iterator itr = arr.iterator();
        while (itr.hasNext())
            System.out.println(itr.next());
  
        Vector<String> vec = new Vector<String>();
        vec.addElement("Tulasi");
        vec.addElement("Gowtham");
        vec.addElement("Suresh");
        vec.addElement("Anuradha");
        System.out.println("\nElements in vector:");
        Enumeration<String> en = vec.elements();
        while (en.hasMoreElements())
           System.out.println(en.nextElement());
    }

}

