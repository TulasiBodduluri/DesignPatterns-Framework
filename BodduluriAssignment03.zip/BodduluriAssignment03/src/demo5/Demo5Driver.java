package demo5;

public class Demo5Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer strbuf=new StringBuffer("Hiii");  
		strbuf.append("tulasi");  
        System.out.println(strbuf);  
        System.out.println(System.nanoTime());
        
        StringBuilder strbuild=new StringBuilder("Hiii");  
        strbuild.append("tulasi");  
        System.out.println(strbuild);  
        System.out.println(System.nanoTime());
	}

}
