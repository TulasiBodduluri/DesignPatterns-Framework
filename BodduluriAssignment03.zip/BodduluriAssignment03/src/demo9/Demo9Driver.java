package demo9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Demo9Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try (BufferedReader r = new BufferedReader(new FileReader("Details.txt"))) {
	         String l = r.readLine();
	         while (l != null) {
	            System.out.println(l);
	            l = r.readLine();
	         }
	      } catch (IOException ex) {
	         ex.printStackTrace();
	      }
	}

}
