package demo3;

public class Demo3Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo3 shape = new Demo3();
		Square square = new Square();
        Rectangle rectangle = new Rectangle();

        Demo3 newShape = shape.draw(); // returns a Shape
        Demo3 newSquare = square.draw(); // returns a Square
        Demo3 newRectangle = rectangle.draw(); // returns a Rectangle

        System.out.println(newShape.getClass()); // prints "class Shape"
        System.out.println(newSquare.getClass()); // prints "class Square"
        System.out.println(newRectangle.getClass()); // prints "class Rectangle"
	}

}
