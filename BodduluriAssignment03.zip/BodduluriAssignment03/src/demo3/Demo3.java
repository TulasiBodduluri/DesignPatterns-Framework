package demo3;

public class Demo3 {
	public Demo3 draw() {
        System.out.println("Drawing shape...");
        return new Demo3();
    }
}

class Square extends Demo3 {
    @Override
    public Square draw() {
        System.out.println("Drawing Square...");
        return new Square();
    }
}

class Rectangle extends Demo3 {
    @Override
    public Rectangle draw() {
        System.out.println("Drawing rectangle...");
        return new Rectangle();
    }
}
