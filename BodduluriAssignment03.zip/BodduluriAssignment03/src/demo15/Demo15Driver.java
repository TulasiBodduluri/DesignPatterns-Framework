package demo15;

import java.util.HashMap;
import java.util.Hashtable;

public class Demo15Driver {
	    public static void main(String[] args) {
	        Hashtable<String, Integer> Person = new Hashtable<>();
	        Person.put("Viji", 24);
	        Person.put("Nikki", 22);
	        Person.put("Tullu", 23);

	        for (String name : Person.keySet()) {
	            int age = Person.get(name);
	            System.out.println(name + "'s age is: " + age);
	        }
	        System.out.println("Using HashMap");
	    HashMap<String, Integer> person2 = new HashMap<>();
	    person2.put("Vidya", 24);
	    person2.put("Nikki", 22);
	    person2.put("Tullu", 23);

        for (String name : person2.keySet()) {
            int age = person2.get(name);
            System.out.println(name + "'s age is: " + age);
        }
	 }  

}

