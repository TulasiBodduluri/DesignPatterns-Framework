package demo6;

public class Demo6Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = "Tulasi";
        String s2 =  "Bodduluri"+s1;
        System.out.println(s2);
        System.out.println(System.nanoTime());
        
        StringBuffer strBuffer=new StringBuffer("Tulasi");  
        strBuffer.append("Bodduluri");  
        System.out.println(strBuffer);  
        System.out.println(System.nanoTime());
	}

}
