package demo19;

public class Demo19Driver extends Thread {
    public void run() {
        System.out.println("Thread is in running state.");
    }
    
    public class MyRunnable implements Runnable {
        public void run() {
            System.out.println("Thread is running.");
        }
    }
public static void main(String args[]) {
	// Creating and starting a thread object
	Demo19Driver t = new Demo19Driver();
	t.start();
	Demo19Driver myRunnable = new Demo19Driver();
	Thread t1 = new Thread(myRunnable);
	t1.start();

}
}