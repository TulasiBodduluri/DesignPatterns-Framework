package demo7;

public class Demo7 {
	public Demo7() {
		System.out.println("Illegal modifier for the "
				+ "constructor in type Demo7; only public, protected & private are permitted...So, "
				+ "Therefore, I just changed the final to public to prevent error in class, and I added the code with final constructor in the doc");
	}
}
