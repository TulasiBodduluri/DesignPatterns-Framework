package demo18;

public class Demo18Driver extends Thread{
    public void run() {
        System.out.println("Thread is in running state...");
    }

    public static void main(String[] args) {
        Demo18Driver thread1 = new Demo18Driver();

        thread1.start(); // First time thread is started

        try {
        	thread1.join(); // Wait for thread to finish
        } catch (InterruptedException ex) {
            ex.printStackTrace();
        }

        // Trying to start the same thread object again will result in an IllegalThreadStateException
        thread1.start(); // Second time thread is started - will throw an exception
    }
}

