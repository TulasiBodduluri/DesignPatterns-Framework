package demo22;

public class Demo22Driver {

	public static void main(String args[]) {
		String s1="Tulasi";
		String s2="Bodduluri "+s1;
		System.out.println(s2);
		System.out.println(s1);
		
		
	}
}