package demo10;

import java.io.FileNotFoundException;
import java.io.IOException;

class SupClass {
    public void func() throws IOException {
        System.out.println("In super class");
    }
}

class SubClass extends SupClass {
    // This is not allowed, it will result in a compile-time error
    public void func() throws FileNotFoundException {
        System.out.println("In sub class");
    }
}

public class Demo10Driver {
    public static void main(String[] args) throws IOException  {
        SupClass sup = new SupClass();
        SubClass sub = new SubClass();
        
        try {
            sup.func();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        
        try {
            sub.func();
        } finally {
        	System.out.println("In finally block");
        }
    }
}
