package demo17;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;


public class Demo17Driver {
	public static void main(String[] args) {
	
	List<Integer> lis = new CopyOnWriteArrayList<>();
	lis.add(10);
	lis.add(20);
	lis.add(30);

	Iterator<Integer> itr = lis.iterator();

	while (itr.hasNext()) {
	    Integer val = itr.next();
	    System.out.println(val);
	    lis.remove(val); // modification during iteration
	}
	List<Integer> l1 = new ArrayList<>();
	l1.add(10);
	l1.add(20);
	l1.add(30);

	Iterator<Integer> itr1 = l1.iterator();

	while (itr1.hasNext()) {
	    Integer val = itr1.next();
	    System.out.println(val);
	    l1.remove(val); // modification during iteration
	}
	
  }
	
}

