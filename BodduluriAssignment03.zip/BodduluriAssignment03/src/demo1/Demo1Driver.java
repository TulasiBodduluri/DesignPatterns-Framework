package demo1;

public class Demo1Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Demo1<Integer> b = new Demo1<>(10);
		b.setVal(50);
		System.out.println(b.getVal());
	}

}
