package demo1;

public class Demo1<B> {
	private B val;

	   public Demo1(B val) {
	      this.val = val;
	   }

	   public B getVal() {
	      return this.val;
	   }

	   public void setVal(B val) {
	      this.val = val;
	   }
}
