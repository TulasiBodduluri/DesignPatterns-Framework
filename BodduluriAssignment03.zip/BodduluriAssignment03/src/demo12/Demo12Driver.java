package demo12;

public class Demo12Driver {
	

	protected void finalize() throws Throwable { 
		try {
			System.out.println("In try Block");
			}
			finally {
			System.out.println("In finally block");
			}
		}

	public static void main(String[] args) throws Throwable {
	final int b = 10;
	System.out.println(b);
	Demo12Driver demo = new Demo12Driver();
	demo.finalize();
	
		}
}
